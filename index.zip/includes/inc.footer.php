<?php
/**
 * Created by PhpStorm.
 * User: tonni
 * Date: 03/01/2019
 * Time: 17:34
 */
?>

<footer class="footer" style="padding-bottom: 1rem!important;">
            <div class="row align-items-center justify-content-xl-between">
                <div class="col-xl-6">
                    <div class="copyright text-center text-xl-left text-muted">
                        &copy; 2018 <a href="https://www.creative-tim.com" class="font-weight-bold ml-1" target="_blank">UENR Clinic System</a>
                    </div>
                </div>
                <div class="col-xl-6">
                    <ul class="nav nav-footer justify-content-center justify-content-xl-end">
                        <li class="nav-item">
                            <a href="#" class="nav-link font-weight-bold">APPIAH Tonnise Danquah</a>
                        </li>
                        <li class="nav-item">
                            <a href="" class="nav-link">Patient Registration</a>
                        </li>
                        <li class="nav-item">
                            <a href="" class="nav-link">Patient List</a>
                        </li>
                        <li class="nav-item">
                            <a href="" class="nav-link">OPD Information</a>
                        </li>
                    </ul>
                </div>
            </div>
        </footer>
