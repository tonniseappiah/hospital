<?php
/**
 * Created by PhpStorm.
 * User: tonni
 * Date: 03/01/2019
 * Time: 08:49
 */

$con = mysqli_connect("localhost", "root", "", "clinic");